from django.db import models
from .ArchivedUserPreferences import ArchivedUserPreferences
from django.utils import timezone

class ArchivedMediaFolder(models.Model):
    archive_name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    archive_created_by_id = models.ForeignKey(ArchivedUserPreferences, on_delete=models.SET_NULL, null=True)
    created_at = models.DateTimeField(auto_now_add=True)  
    updated_at = models.DateTimeField(auto_now=True, null=True) 
    is_deleted = models.BooleanField(default=False, blank=True)
    archived_at = models.DateTimeField(auto_now_add=True)


