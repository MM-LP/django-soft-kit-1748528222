# Extended social media models for Swervetracker (Instagram-style)
from django.db import models
from django.contrib.auth.models import User
from .Post import Post
from django.utils import timezone

# Media attached to posts
class PostMedia(models.Model):
    post_media_id = models.ForeignKey(Post, on_delete=models.SET_NULL, null=True, related_name='media')
    file_id = models.FileField(upload_to='post_media/')
    media_type = models.CharField(max_length=10, choices=[('image', 'Image'), ('video', 'Video')])
    created_at = models.DateTimeField(default=timezone.now)  
    updated_at = models.DateTimeField(default=timezone.now) 
    deleted = models.BooleanField(default=False, blank=True)