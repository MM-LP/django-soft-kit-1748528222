# Extended social media models for Swervetracker (Instagram-style)
from django.db import models
from django.contrib.auth.models import User
from .Post import Post
from django.utils import timezone

# Comments on posts
class Comment(models.Model):
    comment_post_id = models.ForeignKey(Post, on_delete=models.CASCADE, null=True)
    author_id = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    content = models.TextField()
    created_at = models.DateTimeField(default=timezone.now)         # ✅
    updated_at = models.DateTimeField(default=timezone.now) 
    deleted = models.BooleanField(default=False, blank=True)