from django.db import models
from django.utils import timezone

class Activities(models.Model):
    workout_activity = models.CharField(max_length=100, null=True, blank=True)
    workout_desc = models.CharField(max_length=255, null=True, blank=True)
    created_at = models.DateTimeField(default=timezone.now)         # ✅
    updated_at = models.DateTimeField(default=timezone.now) 
    deleted = models.BooleanField(default=False, blank=True)
    deleted = models.BooleanField(default=False, blank=True)