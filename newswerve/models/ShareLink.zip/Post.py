# Extended social media models for Swervetracker (Instagram-style)
from django.db import models
from django.contrib.auth.models import User
from .SetLog import SetLog
from django.utils import timezone

# Post model (shared set + media)
class Post(models.Model):
    user_id = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    setlog_id = models.ForeignKey('SetLog', on_delete=models.SET_NULL, null=True, blank=True)
    caption = models.TextField(blank=True)
    created_at = models.DateTimeField(default=timezone.now)  
    updated_at = models.DateTimeField(default=timezone.now) 
    deleted = models.BooleanField(default=False, blank=True)