from django.db import models
from .MediaFile import MediaFile
from .Tag import Tag

class MediaTag(models.Model):
    media_id = models.ForeignKey(MediaFile, on_delete=models.CASCADE)
    Tag_id = models.ForeignKey(Tag, on_delete=models.CASCADE)
