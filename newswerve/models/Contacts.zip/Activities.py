from django.db import models

class Activities(models.Model):
    workout_activity = models.CharField(max_length=100, null=True, blank=True)
    workout_desc = models.CharField(max_length=255, null=True, blank=True)
    created_at = models.DateTimeField(null=True, blank=True)
    updated_at = models.DateTimeField(null=True, blank=True)