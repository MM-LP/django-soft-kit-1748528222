from django.db import models
from django.contrib.auth.models import User
from .MediaFile import MediaFile
from .UserPreferences import UserPreferences

class Reaction(models.Model):
    media_id = models.ForeignKey(MediaFile, on_delete=models.CASCADE)
    user_id = models.ForeignKey(UserPreferences, on_delete=models.CASCADE)
    type = models.CharField(max_length=20)
    comment = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True, blank=True)
