from django.db import models
from .Contacts import Contacts 

class DriverInfo(models.Model):
    license_number = models.CharField(max_length=50, blank=True, null=True)
    driver_name_id = models.ForeignKey(Contacts, on_delete=models.SET_NULL, null=True)
