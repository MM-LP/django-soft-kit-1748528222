from django.db import models
from .MediaFolder import MediaFolder
from .MediaFile import MediaFile

class MediaInFolder(models.Model):
    folder_id = models.ForeignKey(MediaFolder, on_delete=models.CASCADE)
    media_id = models.ForeignKey(MediaFile, on_delete=models.CASCADE)
    position = models.IntegerField(blank=True, null=True)
