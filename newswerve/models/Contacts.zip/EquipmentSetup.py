from django.db import models
from .ProductInfo import ProductInfo

class EquipmentSetup(models.Model):

    FT_FWD_CHOICES = [
        ('left', 'Left'),
        ('right', 'Right')
    ]
    STEP_CHOICES = [
        ('download', 'App Downloaded'),
        ('guest_login', 'Guest Login'),
        ('create_profile', 'Create Profile'),
        ('record_set', 'First Set Recorded'),
        ('share_set', 'First Set Shared'),
        ('convert_account', 'Converted to Registered'),
        ('feedback', 'Provided Feedback')
    ]

    equip_ski_id = models.ForeignKey(ProductInfo, on_delete=models.CASCADE, related_name='ski_links')
    equip_fin_length = models.IntegerField(blank=True, null=True)
    equip_fin_depth = models.IntegerField(blank=True, null=True)
    equip_fin_DFT = models.DateTimeField(blank=True, null=True)
    equip_fin_leadedge = models.IntegerField(blank=True, null=True)
    equip_fin_wing = models.IntegerField(blank=True, null=True)             # wing angle
    
    equip_boot_id = models.ForeignKey(ProductInfo, on_delete=models.CASCADE, related_name='boot_links')    
    equip_boot_position = models.IntegerField(blank=True, null=True)                      # flag for personal best
    equip_ft_fwd =models.CharField(max_length=6, choices=FT_FWD_CHOICES)
    