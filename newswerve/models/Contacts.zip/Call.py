from django.db import models
from .Contacts import Contacts 

class Call(models.Model):
    contact_id = models.ForeignKey(Contacts, on_delete=models.CASCADE)
    call_time = models.DateTimeField(blank=True, null=True)
    subject = models.CharField(max_length=255, blank=True, null=True)
    notes = models.TextField(blank=True)
