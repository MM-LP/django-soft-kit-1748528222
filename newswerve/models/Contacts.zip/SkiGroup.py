from django.db import models
from django.contrib.auth.models import User

class SkiGroup(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    created_by_id = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_groups')
    members = models.ManyToManyField(User, related_name='SkiGroups')
    created_at = models.DateTimeField(auto_now_add=True, blank=True)
    is_private = models.BooleanField(default=False)

    def __str__(self):
        return self.name