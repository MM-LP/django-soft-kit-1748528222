from django.db import models
from .BoatDetail import BoatDetail
from .Contacts import Contacts

class BoatDriver(models.Model):
    boat_id = models.ForeignKey('BoatDetail', on_delete=models.CASCADE)
    contact_id = models.ForeignKey(Contacts, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.contact.name} - {self.boat}"