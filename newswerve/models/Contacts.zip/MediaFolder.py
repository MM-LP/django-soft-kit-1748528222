from django.db import models
from .UserPreferences import UserPreferences

class MediaFolder(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    created_by_id = models.ForeignKey(UserPreferences, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True, blank=True)
