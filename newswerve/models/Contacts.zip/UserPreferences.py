from django.db import models
from .Metrics import Metrics
from .ProductInfo import ProductInfo
from .Contacts import Contacts
from django.contrib.auth.models import User

class UserPreferences(models.Model):
    user_id = models.ForeignKey(User, on_delete=models.CASCADE, blank=True, null=True)
    bio = models.TextField(blank=True)
    age_range = models.IntegerField(null=True, blank=True)
    user_rope_id = models.ForeignKey(Metrics, on_delete=models.SET_NULL, null=True, related_name='rope_links')
    User_ski_id = models.ForeignKey(ProductInfo, on_delete=models.SET_NULL, null=True)
    user_speed_id = models.ForeignKey(Metrics, on_delete=models.SET_NULL, null=True, related_name='speed_links')
    user_zerooff_id = models.ForeignKey(Metrics, on_delete=models.SET_NULL, null=True,related_name='zerooff_links')
    user_skier = models.BooleanField(default=False)
    user_boat_owner = models.BooleanField(default=False)
    user_driver = models.BooleanField(default=False)
    user_coach = models.BooleanField(default=False)
    user_course_owner = models.BooleanField(default=False)

    # Avatar and new pictures
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)
    pic1 = models.ImageField(upload_to='Contacts/', blank=True, null=True)
    pic2 = models.ImageField(upload_to='Contacts/', blank=True, null=True)
    pic3 = models.ImageField(upload_to='Contacts/', blank=True, null=True)


