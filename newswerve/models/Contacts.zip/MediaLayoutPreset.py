from django.db import models
from .UserPreferences import UserPreferences

class MediaLayoutPreset(models.Model):
    user_id = models.ForeignKey(UserPreferences, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    json_layout = models.JSONField()
    created_at = models.DateTimeField(auto_now_add=True, blank=True)
