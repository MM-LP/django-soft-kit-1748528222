from django.db import models
from .MediaFile import MediaFile
from .UserPreferences import UserPreferences

class ShareLink(models.Model):
    media_id = models.ForeignKey(MediaFile, on_delete=models.CASCADE)
    shared_by_id = models.ForeignKey(UserPreferences, on_delete=models.CASCADE)
    url = models.URLField()
    access_level = models.CharField(max_length=10, choices=[('public', 'Public'), ('private', 'Private')])
    expiration = models.DateTimeField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True, blank=True)
